export const FileRoutes = {
    Home: '/',
    Dashboard: '/dashboard',
    Agencies: '/agencies',
    Division: '/division',
    Location: '/location',
    Users: '/Users'
}