
function Agencies() {
    return (
        <div>Agencies</div>
    )
}

export default Agencies