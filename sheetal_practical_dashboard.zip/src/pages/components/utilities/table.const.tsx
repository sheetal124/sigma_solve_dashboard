const record1 = {
    locationID: '13527',
    locationName: "Stretch Zone - Scarsdale, NY",
    totalLeads: "8",
    social: "8",
}

const record2 = {
    locationID: '14256',
    locationName: "Stretch Zone - Paseo Verde, NV",
    totalLeads: "5",
    social: "5",
}
const record3 = {
    locationID: '15635',
    locationName: "Stretch Zone - Central Park, CO",
    totalLeads: "8",
    social: "8",
}

export { record1, record2, record3 }